# Changelog 

## 3.0.3
* New widget [Presenter](http://metroui.org.ua/presenter.html)
* Datepicker - Triggered change event when date is changed. [#761](https://github.com/olton/Metro-UI-CSS/pull/761)
* upd demo for table
* upd demo for menus
* fix small bugs

## 3.0.2
* Optimize important use
* Alignment version for bower and nuget

## 3.0.1
* Create package for Nuget

## 3.0.0
* Stop version 2.x and Start Metro UI CSS v3
* Register package for Bower